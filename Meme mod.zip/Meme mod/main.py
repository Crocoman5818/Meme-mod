import sys
import os
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtWebChannel import QWebChannel

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.browser = QWebEngineView()

        # Chemin relatif vers le fichier HTML local (index.html dans le dossier Menu)
        file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Menu', 'index.html')
        local_url = QUrl.fromLocalFile(file_path)
        
        # Ouvrir le fichier HTML
        self.browser.setUrl(local_url)
        self.setCentralWidget(self.browser)
        self.showFullScreen()  # Affiche la fenêtre en plein écran

        # Définir le titre de la fenêtre
        self.setWindowTitle('Meme Mod')

        # Configuration du canal Web pour la communication avec JavaScript
        self.channel = QWebChannel()
        self.browser.page().setWebChannel(self.channel)
        self.handler = WebHandler(self)
        self.channel.registerObject('appHandler', self.handler)

class WebHandler(QObject):
    def __init__(self, parent=None):
        super(WebHandler, self).__init__(parent)
        self.parent = parent

    @pyqtSlot()
    def closeApp(self):
        QApplication.instance().quit()  # Ferme l'application

    @pyqtSlot()
    def startNewGame(self):
        # Chemin relatif vers le fichier HTML local (index.html dans le dossier Game)
        file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Game', 'index.html')
        local_url = QUrl.fromLocalFile(file_path)
        self.parent.browser.setUrl(local_url)  # Change la page affichée

app = QApplication(sys.argv)
QApplication.setApplicationName('Meme Mod')
window = MainWindow()
app.exec_()
