// Assurez-vous que QWebChannel est correctement chargé avant ce script
document.addEventListener('DOMContentLoaded', function() {
    // Fonction pour initialiser QWebChannel et définir l'objet de communication
    new QWebChannel(qt.webChannelTransport, function(channel) {
        window.appHandler = channel.objects.appHandler;  // Lien avec l'objet appHandler dans Python
    });

    // Fonction pour démarrer un nouveau jeu
    document.getElementById('new-game').addEventListener('click', function() {
        if (window.appHandler) {
            window.appHandler.startNewGame();  // Appelle la méthode Python pour changer la page
        } else {
            console.error('appHandler is not defined');
        }
    });

    // Fonction pour quitter l'application
    document.getElementById('exit').addEventListener('click', function() {
        if (window.appHandler) {
            window.appHandler.closeApp();  // Appelle la méthode Python pour fermer l'application
        } else {
            console.error('appHandler is not defined');
        }
    });
});
